import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;

public class Driver {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("1. JavaSet");
        System.out.println("2. JavaVector");
        System.out.print("Choose a container (1 or 2): ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Boş satırı oku

        JavaContainer<String> container;

        if (choice == 1) {
            container = new JavaSet<>();
        } else if (choice == 2) {
            container = new JavaVector<>();
        } else {
            System.out.println("Invalid choice. Exiting...");
            return;
        }

        while (true) {
            System.out.println("\n1. Add Element");
            System.out.println("2. Remove Element");
            System.out.println("3. Print Elements");
            System.out.println("4. Write to File");
            System.out.println("5. Exit");
            System.out.print("Choose an option (1-5): ");

            int option = scanner.nextInt();
            scanner.nextLine(); // Boş satırı oku

            switch (option) {
                case 1:
                    System.out.print("Enter element to add: ");
                    String elementToAdd = scanner.nextLine();
                    container.add(elementToAdd);
                    break;
                case 2:
                    System.out.print("Enter element to remove: ");
                    String elementToRemove = scanner.nextLine();
                    container.remove(elementToRemove);
                    break;
                case 3:
                    System.out.println("Container Elements: " + container);
                    System.out.println("Container Size: " + container.size());
                    break;
                case 4:
                    System.out.print("Enter file name: ");
                    String fileName = scanner.nextLine();
                    writeSetToFile(container, fileName);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static <T> void writeSetToFile(JavaContainer<T> container, String fileName) {
        try (FileWriter writer = new FileWriter(fileName)) {
            Iterator<T> iterator = container.getIterator();
            while (iterator.hasNext()) {
                writer.write(iterator.next().toString() + "\n");
            }
            System.out.println("Data written to " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
