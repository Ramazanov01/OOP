//package com.example.container;

import java.util.Iterator;
import java.util.Vector;

public class JavaVector<T> implements JavaContainer<T> {

    private Vector<T> vector = new Vector<>();

    @Override
    public void add(T element) {
        vector.add(element);
    }

    @Override
    public void remove(T element) {
        vector.remove(element);
    }

    @Override
    public int size() {
        return vector.size();
    }

    @Override
    public Iterator<T> getIterator() {
        return vector.iterator();
    }

    @Override
    public String toString() {
        return vector.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        JavaVector<?> javaVector = (JavaVector<?>) obj;
        return vector.equals(javaVector.vector);
    }
}
