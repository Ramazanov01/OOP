//import JavaContainer;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class JavaSet<T> implements JavaContainer<T> {

    private Set<T> set = new HashSet<>();

    @Override
    public void add(T element) {
        set.add(element);
    }

    @Override
    public void remove(T element) {
        set.remove(element);
    }

    @Override
    public int size() {
        return set.size();
    }

    @Override
    public Iterator<T> getIterator() {
        return set.iterator();
    }

    @Override
    public String toString() {
        return set.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        JavaSet<?> javaSet = (JavaSet<?>) obj;
        return set.equals(javaSet.set);
    }
}
