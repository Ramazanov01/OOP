//package com.example.container;

import java.util.Iterator;

public interface JavaContainer<T> {
    void add(T element);
    void remove(T element);
    int size();
    Iterator<T> getIterator();
}
