#include "Simulation.h"

int main()
{
    Simulation sm;
    // run the simulation here
    sm.runSimulation();

    return (0);
}