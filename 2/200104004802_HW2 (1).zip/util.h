#ifndef _UTIL_H_
#define _UTIL_H_
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <ctime>

using namespace std;

struct Node {

    public:
        Node(string name);
        virtual ~Node();

        string getName() const;
        void setName(const string& newName);
        time_t createdTime; // Variable to store the last modification time
        Node* getParent() const;
        void setParent(Node* newParent);

    private:
        string name;
        Node* parent;
};

class Directory : public Node {

    public:
        Directory(string name);
        void addNode(Node* node);
        vector<Node*>& getChildren() { return children; } // const olmayan referans döndürür
        const vector<Node*>& getChildren() const { return children; } // const referans döndürür

        void clearChildren();

    private:
        vector<Node*> children;
};

class Base {

    public:
        virtual ~Base() {}

        virtual void mkdir(const string& directoryName) = 0;
        virtual void ls(const string& options) = 0;
        virtual void rm(const string& fileName) = 0;
        virtual void cd(const string& directoryName) = 0;
        virtual void cp(const string& fileName, const string& destination) = 0;
        virtual void link(const string& fileName, const string& linkName) = 0;
        virtual void cat(const string& fileName) = 0;
};

class FileSystem : public Base {

    public:
        FileSystem();
        ~FileSystem() override;

        void mkdir(const string& directoryName) override;
        void ls(const string& options) override;
        void rm(const string& fileName) override;
        void cd(const string& directoryName) override;
        void cp(const string& fileName, const string& destination) override;
        void link(const string& fileName, const string& linkName) override;
        void cat(const string& fileName) override;
        void cdUp();
        Directory* resolvePath(const std::string& path);
        static void calculatesize(long boyut);

    private:
        Directory* currentDir;
        Directory* rootDir;
        // ... existing private members ...
};

class SymbolicLink : public Node {
public:
    SymbolicLink(Node* target) : Node(target->getName()), target(target) {}

    Node* getTarget() const {
        return target;
    }

private:
    Node* target;
};


#endif // _UTIL_H_
