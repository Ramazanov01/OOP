#include "util.h"
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

int main() {

    FileSystem fileSystem;

    fstream fp("file.txt", std::ios::in | std::ios::out | std::ios::app);

        string arg,arg2,command,words;
        //ifstream fp(fileName);
        while (getline(fp, words)) {

          istringstream ss(words);
          ss >> command;
          if (command == "mkdir") {
              ss >> arg;
              fileSystem.mkdir(arg);
          } else if (command == "cd") {
              ss >> arg;
              fileSystem.cd(arg);
          } else if (command == "cp") {
              ss >> arg >> arg2;
              fileSystem.cp(arg, arg2);
          } else if (command == "link") {
              ss >> arg >> arg2;
              fileSystem.link(arg, arg2);
          } else if (command == "cd..") {
              fileSystem.cdUp();
          }
       }
    fileSystem.calculatesize(0);
    string input;
    fp.clear();
    fp.seekp(0, ios::end);
    cout << "myShell (type 'q' to quit): " << endl;
    while (true) {
        cout << " > ";
        getline(cin, input);
        if (input == "q") {
            break;
        }

        istringstream ss(input);
        ss >> command;

        if (command == "mkdir") {
            ss >> arg;
            fileSystem.mkdir(arg);
            fp << "mkdir\t" << arg << endl;
        } else if (command == "cd") {
            ss >> arg;
            fileSystem.cd(arg);
            fp << "cd\t" << arg << endl;
        } else if (command == "rm") {
            ss >> arg;
            fileSystem.rm(arg);
        } else if (command == "ls") {
            ss >> arg;  // Assuming arg contains options for ls
            fileSystem.ls(arg);
        } else if (command == "cp") {
            ss >> arg >> arg2;
            fileSystem.cp(arg, arg2);
            fp << "cp\t" << arg << "\t" << arg2 << endl;
        } else if (command == "link") {
            ss >> arg >> arg2;
            fileSystem.link(arg, arg2);
            fp << "link\t" << arg << "\t" << arg2 << endl;
        } else if (command == "cat") {
            //ss >> arg;
            //fileSystem.cat(arg);
            ss >> arg; // arg, okunacak dosya adını içerir
            ifstream read_file(arg); // Okunacak dosyayı aç
            if (read_file) {
            string line;
            while (getline(read_file, line)) {
               cout << line << endl; // Dosyanın her satırını ekrana yazdır
            }
            read_file.close();
            } else {
               cerr << "File not found: " << arg << endl;
              }
        } else if (command == "cd..") {
            fileSystem.cdUp();
            fp << "cd.." << endl;
        } else if (command == "cd.") {
            cout <<"same place"<<endl;
        } else cout << "Wrong command" << endl;
    }
    fp.close();
    return 0;
}
