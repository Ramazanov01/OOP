#include "util.h"
#include <iostream>
#include <sstream>
#include <fstream>


using namespace std;

Node::Node(string name) : name(name), parent(nullptr) {}
Node::~Node() {}

string Node::getName() const { return name; }
void Node::setName(const string& newName) { name = newName; }

Node* Node::getParent() const { return parent; }
void Node::setParent(Node* newParent) { parent = newParent; }

Directory::Directory(string name) : Node(name) {}

void Directory::addNode(Node* node) {
    children.push_back(node);
    node->setParent(this);
}

void Directory::clearChildren() { children.clear(); }

FileSystem::FileSystem() {
    currentDir = new Directory("root");
}

FileSystem::~FileSystem() {
    delete currentDir;
}

long totalSize = 0; // Toplam boyutu takip etmek için global değişken

void FileSystem::calculatesize(long boyut) {
    totalSize += boyut;
    if (totalSize > 10 * 1024 * 1024) { // 10 MB kontrolü
        std::cerr << "Your program size more that 10MB." << std::endl;
        exit(1); // Programı sonlandır
    }
}

void FileSystem::cdUp() {
    Node* parent = currentDir->getParent();
    if (parent != nullptr) {
        Directory* parentDir = dynamic_cast<Directory*>(parent);
        if (parentDir != nullptr) {
            currentDir = parentDir;
        }
    }
}

void FileSystem::mkdir(const std::string& directoryName) {

        Directory* newDir = new Directory(directoryName);
        currentDir->addNode(newDir);
        calculatesize(sizeof(newDir));
        time(&newDir->createdTime);
    }

void FileSystem::rm(const string& fileName) {
        auto& children = currentDir->getChildren(); // Referans alın, kopya oluşturmayın
        auto it = find_if(children.begin(), children.end(),
                          [&fileName](const Node* node) { return node->getName() == fileName; });

        if (it != children.end()) {
            delete *it; // Bellekten sil
            children.erase(it); // Listeden çıkar
        }
    }

void FileSystem::cd(const std::string& directoryName) {

        for (auto& child : currentDir->getChildren()) {
            if (child->getName() == directoryName && dynamic_cast<Directory*>(child) != nullptr) {
                currentDir = dynamic_cast<Directory*>(child); // Yeni mevcut dizin

                // Mevcut konumun yolunu oluşturun ve gösterin
                string currentPath = "> ";
                Node* temp = currentDir;
                while (temp != nullptr) {
                    currentPath = temp->getName() + "/" + currentPath;
                    temp = temp->getParent();
                }
                cout << currentPath << endl; // Yol bilgisini yazdır

                break;
            }
        }
    }

Directory* FileSystem::resolvePath(const std::string& path) {
        vector<string> dirs; // Yolu bölerek elde edilen dizin adları
        stringstream ss(path);
        string dir;

        Directory* current;

        // Mutlak yol kontrolü
        if (path.substr(0, 1) == "/" || path.substr(0, 4) == "root") {
            current = rootDir; // Mutlak yol için kök dizinden başla
            if (path.substr(0, 1) == "/") {
                ss.ignore(1); // İlk '/' karakterini atla
            }
        } else {
            current = currentDir; // Göreceli yol için mevcut dizinden başla
        }

        while (getline(ss, dir, '/')) {
            if (dir.empty() || dir == ".") {
                continue; // Geçerli dizinde kal
            } else if (dir == "..") {
                current = dynamic_cast<Directory*>(current->getParent());
                if (current == nullptr) {
                    return nullptr; // Kök dizinin üstüne çıkılamaz
                }
            } else {
                bool found = false;
                for (auto& child : current->getChildren()) {
                    if (child->getName() == dir && dynamic_cast<Directory*>(child) != nullptr) {
                        current = dynamic_cast<Directory*>(child);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    return nullptr; // Dizin bulunamadı
                }
            }
        }

        return current; // Hedef dizini döndür
    }

void FileSystem::cp(const std::string& fileName, const std::string& destination) {
        // Mevcut dizinde dosyayı ara
        Node* fileToCopy = nullptr;
        for (auto& child : currentDir->getChildren()) {
            if (child->getName() == fileName) {
                fileToCopy = child;
                break;
            }
        }
        if (fileToCopy == nullptr) {
            cout << "File not found: " << fileName << endl;
            return;
        }

        // Hedef dizini bul (FileSystem içinde bir yol çözümleme fonksiyonu kullanılabilir)
        Directory* targetDir = resolvePath(destination);

        // Hedef dizin bulunamazsa, işlemi durdur
        if (targetDir == nullptr) {
            cout << "Not found: " << destination << endl;
            return;
        }

        // Hedef dizinde aynı isimde bir dosya varsa, işlemi durdur
        for (auto& child : targetDir->getChildren()) {
            if (child->getName() == fileName) {
                cout << "here have two same name: " << fileName << endl;
                return;
            }
        }

        // Dosyayı kopyala
        Node* copiedFile = new Node(*fileToCopy);
        targetDir->addNode(copiedFile);
        cout << "File copied: " << fileName << " -> " << destination << endl;
    }

void FileSystem::ls(const string& options) {
        // Eğer currentDir null ise, bir şey listelemeye gerek yok
        if (currentDir == nullptr) {
            cout << "Empty here." << endl;
            return;
        }

        // Mevcut dizindeki tüm çocukları (alt dizinleri ve dosyaları) al
        const vector<Node*>& children = currentDir->getChildren();

        // Eğer çocuk yoksa, kullanıcıya bilgi ver
        if (children.empty()) {
            cout << "Empty here." << endl;
            return;
        }

        // Tüm çocukları (alt dizinleri ve dosyaları) listele
        for (const auto& child : children) {
            cout << child->getName();
            char buffer[80];
            struct tm *timeinfo = localtime(&child->createdTime);
            strftime(buffer, 80, "%b %d %H:%M", timeinfo);
            cout << "\t\t\t\t" << buffer << endl;  // 4 tab karakteri ile tarihi ekle
        }
    }

void FileSystem::cat(const std::string& fileName) {
        // Dosya içeriğini görüntüleme işlemleri
    for (auto& child : currentDir->getChildren()) {
        if (child->getName() == fileName) {
            std::cout << "İçerik: [Dosya içeriği burada gösterilecek]" << std::endl;
                // Gerçekte, burada dosya içeriğini diskten okuyup yazdırırsınız.
            return;
        }
    }
    std::cout << "File not found: " << fileName << std::endl;
}

void FileSystem::link(const string& source, const string& destination) {
    // Kaynak ve hedef yolları çözümle
    Node* srcNode = resolvePath(source);
    Node* destNode = resolvePath(destination);

    if (srcNode != nullptr && destNode != nullptr && dynamic_cast<Directory*>(destNode) != nullptr) {
        // Kaynak node'u hedef dizine sembolik olarak bağla
        dynamic_cast<Directory*>(destNode)->addNode(new SymbolicLink(srcNode));
    }
}
