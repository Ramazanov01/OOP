#include<iostream>
#include "piece.h"

Piece::Piece(PieceType type)
{
  if (type == PieceType::ROOK)
      t = 'R';
  else if (type == PieceType::KNIGHT)
      t = 'N';
  else if (type == PieceType::BISHOP)
      t = 'B';
  else if (type == PieceType::QUEEN)
      t = 'Q';
  else if (type == PieceType::KING)
      t = 'K';
  else if (type == PieceType::PAWN)
      t = 'P';
  else if (type == PieceType::ROOK_B)
      t = 'r';
  else if (type == PieceType::KNIGHT_B)
      t = 'n';
  else if (type == PieceType::BISHOP_B)
      t = 'b';
  else if (type == PieceType::QUEEN_B)
      t = 'q';
  else if (type == PieceType::KING_B)
      t = 'k';
  else if (type == PieceType::PAWN_B)
      t = 'p';
      else if (type == PieceType::DOT)
      t = '.';
}


/*
int get_user_move(){

     string input;
     int control=0;

     while(i == 0)
     {
         cout << "Enter your move:";
         cin >>input;
         control = control_board(input);
         if(control == 1)   break;

         else   cout << "Invalid move! Try again." << '\n';
     }

}


int control_board(string& arr){

    int i,j; // a4e5

    if(arr.size() > 4 || arr.size() < 1)     return 0;        // control move length

     char first = arr[0]; // first character
     int second = arr[1] - '0'; // second character (converts from char to int)
     char third = arr[2]; // third character
     int fourth = arr[3] - '0'; // fourth character (converts from char to int)
     int firstmv, thirdmv;
     second -= 1;
     fourth -= 1;
    if( second > 7 || second < 0 || fourth > 7 || fourth < 0 )    return 0;


    switch (tolower(first)) {
      case 'a':  firstmv = 0;
      case 'b':  firstmv = 1;
      case 'c':  firstmv = 2;
      case 'd':  firstmv = 3;
      case 'e':  firstmv = 4;
      case 'f':  firstmv = 5;
      case 'g':  firstmv = 6;
      case 'h':  firstmv = 7;
      default : return 0;
    }

    switch (tolower(third)) {
      case 'a':  thirdmv = 0;
      case 'b':  thirdmv = 1;
      case 'c':  thirdmv = 2;
      case 'd':  thirdmv = 3;
      case 'e':  thirdmv = 4;
      case 'f':  thirdmv = 5;
      case 'g':  thirdmv = 6;
      case 'h':  thirdmv = 7;
      default : return 0;
    }


    if( board[firstmv][second] == 'P' ) // pawn
    {
      if( ( board[thirdmv][fourth] != '.' && firstmv-1 == thirdmv ) && ( second + 1 == fourth || second - 1 == fourth ) )  // if pawn can take a piece
      {
        take_piece(thirdmv,fourth);
        change_board(firstmv,second,thirdmv,fourth);
        return 1;
      }
      if( board[thirdmv][fourth] != '.' && firstmv-2 == thirdmv )  return 0;   // if front not empty and try to move next space
      if( (firstmv-1 != thirdmv || firstmv-2 != thirdmv) && second != fourth )  return 0;  // if try to move front left or right
      if( firstmv == thirdmv && second != fourth )  return 0; // if try to move left or right
      if( firstmv < thirdmv )  return 0;  // if try to move below
      change_board(firstmv,second,thirdmv,fourth);  // if all move legal change_board
      return 1; // legal move
    }


    if( board[firstmv][second] == 'R' ) // rook
    {
      if( board[thirdmv][fourth] != '.' && ( ( second != fourth || firstmv == thirdmv ) || ( second == fourth || firstmv != thirdmv ) ) )
      {
        take_piece(thirdmv,fourth);
        change_board(firstmv,second,thirdmv,fourth);
        return 1;
      }
      if( firstmv == thirdmv && second + 1 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second + 2 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second + 3 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second + 4 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second + 5 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second + 6 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second + 7 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second - 1 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second - 2 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second - 3 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second - 4 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second - 5 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second - 6 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv == thirdmv && second - 7 == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv + 1 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv + 2 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv + 3 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv + 4 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv + 5 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv + 6 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv + 7 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv - 1 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv - 2 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv - 3 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv - 4 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv - 5 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv - 6 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }
      if( firstmv - 7 == thirdmv && second == fourth && board[thirdmv][fourth] == '.' )   {   change_board(firstmv,second,thirdmv,fourth);   return 1;   }

    }


}
*/
