#include "board.h"

int main()
{
  Board b;
  vector<vector<int>> Bpiece;
  int finish=0;
  //ofstream file("output.txt");
  Bpiece.resize(16);   //  here save all pc pieces adresses
  Bpiece[0] = {0 , 0};
  Bpiece[1] = {0 , 1};
  Bpiece[2] = {0 , 2};
  Bpiece[3] = {0 , 3};
  Bpiece[4] = {0 , 4};
  Bpiece[5] = {0 , 5};
  Bpiece[6] = {0 , 6};
  Bpiece[7] = {0 , 7};
  Bpiece[8] = {1 , 0};
  Bpiece[9] = {1 , 1};
  Bpiece[10] = {1 , 2};
  Bpiece[11] = {1 , 3};
  Bpiece[12] = {1 , 4};
  Bpiece[13] = {1 , 5};
  Bpiece[14] = {1 , 6};
  Bpiece[15] = {1 , 7};

  b.build_board();
  cout << "Loading!!! User white  -  computer black\n";
  while(finish == 0)
  {
     cout << "User point : " << b.get_user_point() << "  PC point: " << b.get_pc_point() << endl;
     b.print_board();
     cout << "\n[White's turn] ";
     b.get_user_move(Bpiece);
     b.print_board();
     cout << "\n[Black's turn] \n ";
     b.get_move_pc(Bpiece);
     finish = b.get_finish();
  }
  if( finish == 1 ) cout << "User win\n";
  else cout << "Computer win\n";
  return 0;
}
