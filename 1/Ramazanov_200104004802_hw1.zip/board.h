#ifndef _BOARD_H_
#define _BOARD_H_
#include <vector>
#include "piece.h"
#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;


class Board {

     private:

         vector<vector<Piece>> board;
         double user_point=0;
         double pc_point=0;
         int finish=0;
     public:

         vector<vector<Piece>> get_board() { return board; };
         void set_user_point(double a) { user_point += a; };
         void set_pc_point(double a ) { pc_point += a; };
         void set_finish( int c )  { finish = c; };
         double get_user_point() { return user_point; };
         double get_pc_point() { return pc_point; };
         int get_finish()  { return finish; }
         void print_board();
         void build_board();
         int get_user_move(vector<vector<int>>& adres);
         void get_move_pc(vector<vector<int>>& a);
         int control_board(string& arr,vector<vector<int>>& adres);
         void take_piece(int a,int b,vector<vector<int>>& adres);
         void change_board(int a,int b,int c,int d);

};
#endif
