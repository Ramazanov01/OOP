#include "board.h"

void Board::print_board(){  // printed board here
     ofstream file("output.txt",ios::app);
     for (int i = 0; i < 8; i++)
     {
          cout << "" << 8 - i << "| ";
          for (int j = 0; j < 8; j++)
              cout << board[i][j].get_t() << " ";
          cout << '\n';
     }
     cout << "-------------------\n";
     cout << "   a b c d e f g h\n";
     if (file.is_open()) {
        for (int i = 0; i < 8; i++) {
            file << "" << 8 - i << "| ";
            for (int j = 0; j < 8; j++)
                file << board[i][j].get_t() << " ";
            file << '\n';
        }
        file << "-------------------\n";
        file << "   a b c d e f g h\n";
    } else {
        std::cout << "Dosya açılamadı!\n"; // Dosya açılamazsa ekrana hata mesajı yaz
    }
    file.close();
}

void Board::change_board(int a, int b, int c, int d) {

       if ( board[c][d].get_t() == 'p' || board[c][d].get_t() == 'P' )
       {
          if(board[c][d].get_t() == 'p')
          {
              set_user_point(+1);
          }
          else set_pc_point(1);

       }
       else if ( board[c][d].get_t() == 'b' || board[c][d].get_t() == 'B' )
       {
          if(board[c][d].get_t() == 'b')
          {
              set_user_point(+3);
          }
          else set_pc_point(3);

       }
       else if ( board[c][d].get_t() == 'n' || board[c][d].get_t() == 'N' )
       {
          if(board[c][d].get_t() == 'n')
          {
              set_user_point(+3);
          }
          else set_pc_point(3);

       }
       else if ( board[c][d].get_t() == 'q' || board[c][d].get_t() == 'Q' )
       {
          if(board[c][d].get_t() == 'q')
          {
              set_user_point(+9);
          }
          else set_pc_point(9);

       }
       else if ( board[c][d].get_t() == 'r' || board[c][d].get_t() == 'R' )
       {
          if(board[c][d].get_t() == 'r')
          {
              set_user_point(+5);
          }
          else set_pc_point(5);

       }
       else if ( board[c][d].get_t() == 'k' || board[c][d].get_t() == 'K' )
       {
          if( board[c][d].get_t() == 'k' )   set_finish(1);
          else  set_finish(-1);
       }
       board[c][d].set_t(board[a][b].get_t());
       board[a][b].set_t('.');

    }

void Board::build_board() {

     board.resize(8);
     // here fulled board with pieces
     board[7].push_back(Piece(PieceType::ROOK));
     board[7].push_back(Piece(PieceType::KNIGHT));
     board[7].push_back(Piece(PieceType::BISHOP));
     board[7].push_back(Piece(PieceType::QUEEN));
     board[7].push_back(Piece(PieceType::KING));
     board[7].push_back(Piece(PieceType::BISHOP));
     board[7].push_back(Piece(PieceType::KNIGHT));
     board[7].push_back(Piece(PieceType::ROOK));
     for (int i = 0; i < 8; i++)
         board[6].push_back(Piece(PieceType::PAWN));

      board[0].push_back(Piece(PieceType::ROOK_B));
      board[0].push_back(Piece(PieceType::KNIGHT_B));
      board[0].push_back(Piece(PieceType::BISHOP_B));
      board[0].push_back(Piece(PieceType::QUEEN_B));
      board[0].push_back(Piece(PieceType::KING_B));
      board[0].push_back(Piece(PieceType::BISHOP_B));
      board[0].push_back(Piece(PieceType::KNIGHT_B));
      board[0].push_back(Piece(PieceType::ROOK_B));
      for (int i = 0; i < 8; i++)
          board[1].push_back(Piece(PieceType::PAWN_B));

     for (int i = 2; i < 6; ++i) {  // here filled empty spaeces with dot
        for (int j = 0; j < 8; j++)
          board[i].push_back(Piece(PieceType::DOT));
        }
}

void Board::take_piece(int a, int b, vector<vector<int>>& c){

   for(int i=0; i<16; i++)
   {
     if ( c[i][0] == a && c[i][1] == b )
     {
        c[i][0] = -1;
        c[i][1] = -1;
     }
   }
}

int Board::get_user_move(vector<vector<int>>& adres){

     string input;
     int control=0;

     while(control == 0)
     {
         cout << "Enter your move:";
         cin >>input;
         cout << '\n';
         control = control_board(input,adres);
         if(control == 1)   break;
         else   cout << "Invalid move! Try again." << '\n';
     }

     return 0;

}

int Board::control_board(string& arr, vector<vector<int>>& adres){

    int i,j; // a4e5

    if(arr.size() > 4 || arr.size() < 1)     return 0;        // control move length
     char first = arr[0]; // first character
     int second = arr[1] - '0'; // second character (converts from char to int)
     char third = arr[2]; // third character
     int fourth = arr[3] - '0'; // fourth character (converts from char to int)
     int firstmv, thirdmv;
     second = 8 - second;
     fourth = 8 - fourth;
     if( second > 8 || second < 0 || fourth > 8 || fourth < 0 )    return 0;
    switch (tolower(first)) {
      case 'a':  firstmv = 0;   break;
      case 'b':  firstmv = 1;   break;
      case 'c':  firstmv = 2;   break;
      case 'd':  firstmv = 3;   break;
      case 'e':  firstmv = 4;   break;
      case 'f':  firstmv = 5;   break;
      case 'g':  firstmv = 6;   break;
      case 'h':  firstmv = 7;   break;
      default : return 0;       break;
    }

    switch (tolower(third)) {
      case 'a':  thirdmv = 0;   break;
      case 'b':  thirdmv = 1;   break;
      case 'c':  thirdmv = 2;   break;
      case 'd':  thirdmv = 3;   break;
      case 'e':  thirdmv = 4;   break;
      case 'f':  thirdmv = 5;   break;
      case 'g':  thirdmv = 6;   break;
      case 'h':  thirdmv = 7;   break;
      default : return 0;       break;
    }

    if ( board[second][firstmv].get_t() == 'P' ) // Pawn
    {
        if ( ( board[fourth][thirdmv].get_t() != '.' && second - 1 == fourth ) && ( (firstmv + 1 == thirdmv) || (firstmv - 1 == thirdmv) ) && board[fourth][thirdmv].get_t() != 'P' && board[fourth][thirdmv].get_t() != 'B' && board[fourth][thirdmv].get_t() != 'N' && board[fourth][thirdmv].get_t() != 'K' && board[fourth][thirdmv].get_t() != 'Q' )  // Pawn captures a piece
        {
            take_piece(fourth, thirdmv, adres);
            change_board(second, firstmv, fourth, thirdmv);
            return 1;
        }

        if ( board[fourth][thirdmv].get_t() != '.' && second - 2 == fourth )  // Trying to move two spaces ahead when front is not empty
            return 0;

        if ( (second - 1 != fourth && second - 2 != fourth) || firstmv != thirdmv )  // Attempting to move front left or right or trying to move left or right
            return 0;

        if ( second < fourth )  // Attempting to move below
            return 0;

        change_board(second, firstmv, fourth, thirdmv);  // If all moves are legal, execute the move
        return 1; // Legal move
    }
    else if (board[second][firstmv].get_t() == 'B') // Rook
    {
        if (abs(fourth - thirdmv) == 2)
        {
            int row = second;
            int col = firstmv;

            int rowDirection = (fourth - row) > 0 ? 1 : -1;
            int colDirection = (thirdmv - col) > 0 ? 1 : -1;

            row += rowDirection;
            col += colDirection;

            while (row != fourth && col != thirdmv)
            {
                if (board[row][col].get_t() != '.')
                {
                    return 0;
                }
                row += rowDirection;
                col += colDirection;
            }

            if (board[fourth][thirdmv].get_t() == '.')
            {
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
            else
            {
                take_piece(fourth, thirdmv, adres);
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
        }
        else
        {
            return 0;
        }
    }
    else if (board[second][firstmv].get_t() == 'R') // Rook
    {
        if (second == fourth && firstmv != thirdmv) // Yatay hareket
        {
            int step = firstmv < thirdmv ? 1 : -1;
            for (int i = firstmv + step; i != thirdmv; i += step)
            {
                if (board[second][i].get_t() != '.')
                {
                    return 0; // Yolda bir taş var, geçemez
                }
            }

            if (board[fourth][thirdmv].get_t() == '.')
            {
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
            else
            {
                take_piece(fourth, thirdmv, adres);
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
        }
        else if (second != fourth && firstmv == thirdmv) // Dikey hareket
        {
            int step = second < fourth ? 1 : -1;
            for (int i = second + step; i != fourth; i += step)
            {
                if (board[i][firstmv].get_t() != '.')
                {
                    return 0; // Yolda bir taş var, geçemez
                }
            }

            if (board[fourth][thirdmv].get_t() == '.')
            {
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
            else
            {
                take_piece(fourth, thirdmv, adres);
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
        }
        else
        {
            return 0;
        }
    }

    else if ( board[second][firstmv].get_t() == 'N' )
    {
       if ( abs(second-fourth) == 1 && abs(firstmv-thirdmv) == 2 )
       {
         if ( board[fourth][thirdmv].get_t() == '.' )
         {
            change_board(second,firstmv,fourth,thirdmv);
            return 1;
         }
         else
         {
            take_piece(fourth,thirdmv,adres);
            change_board(second,firstmv,fourth,thirdmv);
            return 1;
         }
       }
       else if ( abs(second-fourth) == 2 && abs(firstmv-thirdmv) == 1 )
       {
         if ( board[fourth][thirdmv].get_t() == '.' )
         {
            change_board(second,firstmv,fourth,thirdmv);
            return 1;
         }
         else
         {
            take_piece(fourth,thirdmv,adres);
            change_board(second,firstmv,fourth,thirdmv);
            return 1;
         }
       }
       else  return 0;
    }

    else if (board[second][firstmv].get_t() == 'Q') // Queen
    {
        if (second == fourth && firstmv != thirdmv) // Yatay hareket
        {
            int step = firstmv < thirdmv ? 1 : -1;
            for (int i = firstmv + step; i != thirdmv; i += step)
            {
                if (board[second][i].get_t() != '.')
                {
                    return 0; // Yolda bir taş var, geçemez
                }
            }

            if (board[fourth][thirdmv].get_t() == '.')
            {
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
            else
            {
                take_piece(fourth, thirdmv, adres);
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
        }
        else if (second != fourth && firstmv == thirdmv) // Dikey hareket
        {
            int step = second < fourth ? 1 : -1;
            for (int i = second + step; i != fourth; i += step)
            {
                if (board[i][firstmv].get_t() != '.')
                {
                    return 0; // Yolda bir taş var, geçemez
                }
            }

            if (board[fourth][thirdmv].get_t() == '.')
            {
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
            else
            {
                take_piece(fourth, thirdmv, adres);
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
        }
        else if (abs(fourth - thirdmv) == 2)
        {
            int row = second;
            int col = firstmv;

            int rowDirection = (fourth - row) > 0 ? 1 : -1;
            int colDirection = (thirdmv - col) > 0 ? 1 : -1;

            row += rowDirection;
            col += colDirection;

            while (row != fourth && col != thirdmv)
            {
                if (board[row][col].get_t() != '.')
                {
                    return 0;
                }
                row += rowDirection;
                col += colDirection;
            }

            if (board[fourth][thirdmv].get_t() == '.')
            {
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
            else
            {
                take_piece(fourth, thirdmv, adres);
                change_board(second, firstmv, fourth, thirdmv);
                return 1;
            }
        }
        else
        {
            return 0;
        }
    }


    else if ( board[second][firstmv].get_t() == 'K' )   // KİNG
    {
      if ( abs(fourth-second) <= 1 && abs(thirdmv-firstmv) <= 1 && board[fourth][thirdmv].get_t() != 'P' && board[fourth][thirdmv].get_t() != 'R' && board[fourth][thirdmv].get_t() != 'N' && board[fourth][thirdmv].get_t() != 'B' && board[fourth][thirdmv].get_t() != 'Q' )
      {
         if ( board[fourth][thirdmv].get_t() == '.' )
         {
            change_board(second,firstmv,fourth,thirdmv);
            return 1;
         }
         else
         {
           take_piece(fourth,thirdmv,adres);
           change_board(second,firstmv,fourth,thirdmv);
           return 1;
         }
      }
      else  return 0;
    }
    else return 0;
}



void Board::get_move_pc ( vector<vector<int>>& a ) {

     int control=0;
     while(control<16)
     {
       while( a[control][0] == -1 )  control++;
       int col = a[control][0];
       int row = a[control][1];
       if ( board[col][row].get_t() == 'r' )   // control rook's  move if it take a piece
       {
          for(int i=col+1; i<8; i++)
          {
             if ( board[i][row].get_t() != 'p' && board[i][row].get_t() != 'r' && board[i][row].get_t() != 'n' && board[i][row].get_t() != 'b' && board[i][row].get_t() != 'q' && board[i][row].get_t() != 'k' )
             {
                if ( board[i][row].get_t() != '.' )
                {
                   change_board(col,row,i,row);
                   a[control][0] = i;
                   a[control][1] = row;
                   return;
                }
                else  continue;
             }
             else break;
          }

          for(int i=col-1; i>-1; i--)
          {
             if ( board[i][row].get_t() != 'p' && board[i][row].get_t() != 'r' && board[i][row].get_t() != 'n' && board[i][row].get_t() != 'b' && board[i][row].get_t() != 'q' && board[i][row].get_t() != 'k' )
             {
                if ( board[i][row].get_t() != '.' )
                {
                   change_board(col,row,i,row);
                   a[control][0] = i;
                   a[control][1] = row;
                   return;
                }
                else  continue;
             }
             else break;
          }

          for(int i=row-1; i>-1; i--)
          {
             if ( board[col][i].get_t() != 'p' && board[col][i].get_t() != 'r' && board[col][i].get_t() != 'n' && board[col][i].get_t() != 'b' && board[col][i].get_t() != 'q' && board[col][i].get_t() != 'k' )
             {
                if ( board[col][i].get_t() != '.' )
                {
                   change_board(col,row,col,i);
                   a[control][0] = col;
                   a[control][1] = i;
                   return;
                }
                else  continue;
             }
             else break;
          }

          for(int i=row+1; i<8; i++)
          {
             if ( board[col][i].get_t() != 'p' && board[col][i].get_t() != 'r' && board[col][i].get_t() != 'n' && board[col][i].get_t() != 'b' && board[col][i].get_t() != 'q' && board[col][i].get_t() != 'k' )
             {
                if ( board[col][i].get_t() != '.' )
                {
                   change_board(col,row,col,i);
                   a[control][0] = col;
                   a[control][1] = i;
                   return;
                }
                else  continue;
             }
             else break;
          }
       }
       else if (board[col][row].get_t() == 'b') { // control bishop's move if it takes a piece
          // Diagonal down-right
          int i = col + 1, j = row + 1;
          while (i < 8 && j < 8) {
             if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k')
             {
                if (board[i][j].get_t() != '.')
                {
                   change_board(col, row, i, j);
                   a[control][0] = i;
                   a[control][1] = j;
                   return;
                }
                else
                {
                   i++;
                   j++;
                   continue;
                }
             }
             else break;
          }
          // Diagonal down-right
          i = col - 1; j = row + 1;
          while (i >= 0 && j < 8) {
             if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                if (board[i][j].get_t() != '.') {
                   change_board(col, row, i, j);
                   a[control][0] = i;
                   a[control][1] = j;
                   return;
                }
                else
                {
                   i--;
                   j++;
                   continue;
                }
             }
             else break;
           }
           // Diagonal up-left
           i = col + 1; j = row - 1;
           while (i < 8 && j >= 0) {
              if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                 if (board[i][j].get_t() != '.') {
                    change_board(col, row, i, j);
                    a[control][0] = i;
                    a[control][1] = j;
                    return;
                 }
                 else
                 {
                    i++;
                    j--;
                    continue;
                 }
              }
              else break;
           }
           // Diagonal down-left
           i = col - 1; j = row - 1;
           while (i >= 0 && j >= 0) {
              if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                 if (board[i][j].get_t() != '.') {
                    change_board(col, row, i, j);
                    a[control][0] = i;
                    a[control][1] = j;
                    return;
                 }
                 else
                 {
                    i--;
                    j--;
                    continue;
                 }
              }
              else break;
           }
        }
        else if (board[col][row].get_t() == 'n') { // control knight's move if it takes a piece
           // Possible moves for a knight
           int moves[8][2] = {{-2, -1}, {-1, -2}, {1, -2}, {2, -1}, {2, 1}, {1, 2}, {-1, 2}, {-2, 1}};

           for (int k = 0; k < 8; ++k) {
               int next_col = col + moves[k][0];
               int next_row = row + moves[k][1];

               if (next_col >= 0 && next_col < 8 && next_row >= 0 && next_row < 8) {
                  if (board[next_col][next_row].get_t() != 'p' && board[next_col][next_row].get_t() != 'r' &&
                     board[next_col][next_row].get_t() != 'n' && board[next_col][next_row].get_t() != 'b' &&
                     board[next_col][next_row].get_t() != 'q' && board[next_col][next_row].get_t() != 'k') {
                     if (board[next_col][next_row].get_t() != '.') {
                        change_board(col, row, next_col, next_row);
                        a[control][0] = next_col;
                        a[control][1] = next_row;
                        return;
                     }
                  }
               }
           }
        }
        else if (board[col][row].get_t() == 'q') { // Control queen's move if it takes a piece
            // Diagonal up-right
            int i = col + 1, j = row + 1;
            while (i < 8 && j < 8) {
                if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                    if (board[i][j].get_t() != '.') {
                        change_board(col, row, i, j);
                        a[control][0] = i;
                        a[control][1] = j;
                        return;
                    } else {
                        i++;
                        j++;
                        continue;
                    }
                } else break;
            }

            // Diagonal up-left
            i = col - 1, j = row + 1;
            while (i >= 0 && j < 8) {
                if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                    if (board[i][j].get_t() != '.') {
                        change_board(col, row, i, j);
                        a[control][0] = i;
                        a[control][1] = j;
                        return;
                    } else {
                        i--;
                        j++;
                        continue;
                    }
                } else break;
            }

            // Diagonal down-right
            i = col + 1, j = row - 1;
            while (i < 8 && j >= 0) {
                if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t()!= 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                    if (board[i][j].get_t() != '.') {
                        change_board(col, row, i, j);
                        a[control][0] = i;
                        a[control][1] = j;
                        return;
                    } else {
                        i++;
                        j--;
                        continue;
                    }
                } else break;
            }

            // Diagonal down-left
            i = col - 1, j = row - 1;
            while (i >= 0 && j >= 0) {
                if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                    if (board[i][j].get_t() != '.') {
                        change_board(col, row, i, j);
                        a[control][0] = i;
                        a[control][1] = j;
                        return;
                    } else {
                        i--;
                        j--;
                        continue;
                    }
                } else break;
            }

            // Straight up
            i = col, j = row + 1;
            while (j < 8) {
                if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                    if (board[i][j].get_t() != '.') {
                        change_board(col, row, i, j);
                        a[control][0] = i;
                        a[control][1] = j;
                        return;
                    } else {
                        j++;
                        continue;
                    }
                } else break;
            }

            // Straight down
            i = col, j = row - 1;
            while (j >= 0) {
                if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                    if (board[i][j].get_t() != '.') {
                        change_board(col, row, i, j);
                        a[control][0] = i;
                        a[control][1] = j;
                        return;
                    } else {
                        j--;
                        continue;
                    }
                } else break;
            }

            // Straight right
            i = col + 1, j = row;
            while (i < 8) {
                if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t() != 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                    if (board[i][j].get_t() != '.') {
                        change_board(col, row, i, j);
                        a[control][0] = i;
                        a[control][1] = j;
                        return;
                    } else {
                        i++;
                        continue;
                    }
                } else break;
            }

            // Straight left
            i = col - 1, j = row;
            while (i >= 0) {
                if (board[i][j].get_t() != 'p' && board[i][j].get_t() != 'r' && board[i][j].get_t() != 'n' && board[i][j].get_t()!= 'b' && board[i][j].get_t() != 'q' && board[i][j].get_t() != 'k') {
                    if (board[i][j].get_t() != '.') {
                        change_board(col, row, i, j);
                        a[control][0] = i;
                        a[control][1] = j;
                        return;
                    } else {
                        i--;
                        continue;
                    }
                } else break;
            }
         }
         else if (board[col][row].get_t() == 'k') { // control king's move if it takes a piece
             // Possible moves for a king
             int moves[8][2] = {{-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}};

             for (int k = 0; k < 8; ++k) {
                 int next_col = col + moves[k][0];
                 int next_row = row + moves[k][1];

                 if (next_col >= 0 && next_col < 8 && next_row >= 0 && next_row < 8) {
                     if (board[next_col][next_row].get_t() != 'p' && board[next_col][next_row].get_t() != 'r' &&
                     board[next_col][next_row].get_t() != 'n' && board[next_col][next_row].get_t() != 'b' &&
                     board[next_col][next_row].get_t() != 'q' && board[next_col][next_row].get_t() != 'k') {
                         if (board[next_col][next_row].get_t() != '.') {
                             change_board(col, row, next_col, next_row);
                             a[control][0] = next_col;
                             a[control][1] = next_row;
                             return;
                         }
                     }
                 }
             }
         }
         else if (board[col][row].get_t() == 'p') { // Control pawn's move if it takes a piece
            // Moving forward
            if ( row+1 < 8 && board[col+1][row+1].get_t() != 'p' && board[col+1][row+1].get_t() != 'r' && board[col+1][row+1].get_t() != 'n' && board[col+1][row+1].get_t() != 'b' && board[col+1][row+1].get_t() != 'q' && board[col+1][row+1].get_t() != 'k' )
            {
               if ( board[col+1][row+1].get_t() != '.' )
               {
                 change_board(col, row, col+1, row+1);
                 a[control][0] = col+1;
                 a[control][1] = row+1;
                 return;
               }
            }
            if ( row-1 > -1 && board[col+1][row-1].get_t() != 'p' && board[col+1][row-1].get_t() != 'r' && board[col+1][row-1].get_t() != 'n' && board[col+1][row-1].get_t() != 'b' && board[col+1][row-1].get_t() != 'q' && board[col+1][row-1].get_t() != 'k' )
            {
               if ( board[col+1][row-1].get_t() != '.' )
               {
                 change_board(col, row, col+1, row-1);
                 a[control][0] = col+1;
                 a[control][1] = row-1;
                 return;
               }
            }
         }
       control++;
     }
     int suggest=0;
     int random,col,row;
     srand(time(NULL));
     while ( suggest != 1 )   //  if computer can not take a piece then make a move random
     {
        random = rand() % 16;
        col = a[random][0];
        row = a[random][1];
        if ( a[random][0] != -1 )
        {
           if ( board[col][row].get_t() == 'p' )  //  random pawn move
           {
              if ( board[col+1][row].get_t() == '.' && col+1 < 8 )
              {
                 change_board(col,row,col+1,row);
                 suggest = 1;
              }
           }
           else if ( board[col][row].get_t() == 'n' )   //  random knight  move
           {
              if ( col+2 < 8 && row+1 < 8 && board[col+2][row+1].get_t() == '.' )
              {
                change_board(col,row,col+2,row+1);
                suggest = 1;

              }
              else if ( col+2 < 8 && row-1 > -1 && board[col+2][row-1].get_t() == '.' )
              {
                change_board(col,row,col+2,row-1);
                suggest = 1;

              }
              else if ( col-2 > -1 && row-1 > -1 && board[col-2][row-1].get_t() == '.' )
              {
                change_board(col,row,col-2,row-1);
                suggest = 1;

              }
              else if ( col-2 > -1 && row+1 <8 && board[col-2][row+1].get_t() == '.' )
              {
                change_board(col,row,col-2,row+1);
                suggest = 1;

              }
              else if ( col+1 < 8 && row+2 < 8 && board[col+1][row+2].get_t() == '.' )
              {
                change_board(col,row,col+1,row+2);
                suggest = 1;
              }
           }
           else if ( board[col][row].get_t() == 'b' )   //  random bishop  move
           {
               if ( col+2 < 8 && row+2 < 8 && board[col+1][row+1].get_t() == '.' && board[col+2][row+2].get_t() == '.' )
               {
                 change_board(col,row,col+2,row+2);
                 suggest = 1;
               }
               else if ( col+2 < 8 && row-2 > -1 && board[col+1][row-1].get_t() == '.' && board[col+2][row-2].get_t() == '.' )
               {
                 change_board(col,row,col+2,row-2);
                 suggest = 1;
               }
               else if ( col-2 > -1 && row-2 > -1 && board[col-1][row-1].get_t() == '.' && board[col-2][row-2].get_t() == '.' )
               {
                 change_board(col,row,col-2,row-2);
                 suggest = 1;
               }
               else if ( col-2 > -1 && row+2 <8 && board[col-1][row+1].get_t() == '.' && board[col-2][row+2].get_t() == '.' )
               {
                 change_board(col,row,col-2,row+2);
                 suggest = 1;
               }
           }
           else if ( board[col][row].get_t() == 'r' )  // random rook movie
           {
               if ( row+2 < 8  && board[col][row+1].get_t() == '.' && board[col][row+2].get_t() == '.' )
               {
                 change_board(col,row,col,row+2);
                 suggest = 1;
               }
               else if ( row-2 > -1 && board[col][row-1].get_t() == '.' && board[col][row-2].get_t() == '.' )
               {
                 change_board(col,row,col,row-2);
                 suggest = 1;
               }
               else if ( col-2 > -1 && board[col-1][row].get_t() == '.' && board[col-2][row].get_t() == '.' )
               {
                 change_board(col,row,col-2,row);
                 suggest = 1;
               }
               else if ( col+2 < 8 && board[col+1][row].get_t() == '.' && board[col+2][row].get_t() == '.' )
               {
                 change_board(col,row,col+2,row);
                 suggest = 1;
               }
           }
           else if ( board[col][row].get_t() == 'q' )  //  random  queen movie
           {
               if ( col+2 < 8 && row+2 < 8 && board[col+1][row+1].get_t() == '.' && board[col+2][row+2].get_t() == '.' )
               {
                 change_board(col,row,col+2,row+2);
                 suggest = 1;
               }
               else if ( col+2 < 8 && row-2 > -1 && board[col+1][row-1].get_t() == '.' && board[col+2][row-2].get_t() == '.' )
               {
                 change_board(col,row,col+2,row-2);
                 suggest = 1;
               }
               else if ( col-2 > -1 && row-2 > -1 && board[col-1][row-1].get_t() == '.' && board[col-2][row-2].get_t() == '.' )
               {
                 change_board(col,row,col-2,row-2);
                 suggest = 1;
               }
               else if ( col-2 > -1 && row+2 <8 && board[col-1][row+1].get_t() == '.' && board[col-2][row+2].get_t() == '.' )
               {
                 change_board(col,row,col-2,row+2);
                 suggest = 1;
               }
               if ( row+2 < 8 && board[col][row+1].get_t() == '.' && board[col][row+2].get_t() == '.' )
               {
                 change_board(col,row,col,row+2);
                 suggest = 1;
               }
               else if ( row-2 > -1 && board[col][row-1].get_t() == '.' && board[col][row-2].get_t() == '.' )
               {
                 change_board(col,row,col,row-2);
                 suggest = 1;
               }
               else if ( col-2 > -1 && board[col-1][row].get_t() == '.' && board[col-2][row].get_t() == '.' )
               {
                 change_board(col,row,col-2,row);
                 suggest = 1;
               }
               else if ( col+2 < 8 && board[col+1][row].get_t() == '.' && board[col+2][row].get_t() == '.' )
               {
                 change_board(col,row,col+2,row);
                 suggest = 1;
               }
           }
           else if ( board[col][row].get_t() == 'q' )
           {
               if( col - 1 > -1 && board[col-1][row].get_t() == '.' )
               {
                 change_board(col,row,col-1,row);
                 suggest = 1;
               }
               else if( col + 1 < 8 && board[col+1][row].get_t() == '.' )
               {
                 change_board(col,row,col+1,row);
                 suggest = 1;
               }
               else if( row - 1 > -1 && board[col][row-1].get_t() == '.' )
               {
                 change_board(col,row,col,row-1);
                 suggest = 1;
               }
               else if( row + 1 < 8 && board[col][row+1].get_t() == '.' )
               {
                 change_board(col,row,col,row+1);
                 suggest = 1;
               }
           }

        }
     }

     return;
  }
