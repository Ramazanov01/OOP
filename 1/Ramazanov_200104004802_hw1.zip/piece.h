#ifndef _PIECE_H_
# define _PIECE_H_
#include <string>
#include <iostream>

using namespace std;

enum class PieceType {
    PAWN = 'P',
    KNIGHT = 'N',
    BISHOP = 'B',
    ROOK = 'R',
    QUEEN = 'Q',
    KING = 'K',
    DOT = '.',
    PAWN_B = 'p',
    KNIGHT_B = 'n',
    BISHOP_B = 'b',
    ROOK_B = 'r',
    QUEEN_B = 'q',
    KING_B = 'k'
};


class Piece {

     private:
            char t;
     public:
          Piece(PieceType type);
          void set_t( char a )  { t = a;   }
          char get_t() {return t;};
};
 #endif
